class ExperiencePro
{
  DateTime dateDebut;
  DateTime dateFin;
  String raisonSociale;
  String ville;
  List<String>taches;
  List<String>technologies;
  List<String> environements;
  List<String> postesTravail;


  ExperiencePro(this.dateDebut, this.dateFin, this.raisonSociale, this.ville,
      this.taches, this.technologies, this.environements,this.postesTravail);

}