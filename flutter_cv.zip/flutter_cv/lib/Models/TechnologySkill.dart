class TechnologySkill
{
  String label;
  String imageName;
  int level;

  TechnologySkill(this.label, this.imageName, this.level);

}