class Cursus
{
  int annee;
  String label;
  String organisme;
  String city;
  String info;
  bool diplome;
  Cursus(this.annee, this.label,this.organisme, this.city, this.info,this.diplome);

}