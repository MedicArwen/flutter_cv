import 'package:flutter/material.dart';
import 'package:fluttercv/Controleurs/homepage/HomePageState.dart';

class HomePage extends StatefulWidget {
  static Color yellow= Color(0xFFFA9917);
  static Color bleu= Color(0xFF46B9E9);
  @override
  State<HomePage> createState() => HomePageState();


}
